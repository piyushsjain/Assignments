﻿using System;
using System.Collections.Generic;

namespace Exercise6
{
    public class Program6
    {
        public void Question6()
        {
            Equipment e1 = new Mobile();
            Equipment e2 = new Immobile();

            e1.name = "Car";
            e1.description = "It has 4 tyres";
            e1.moveBy(2, 6);
            
            e2.name = "Ladder";
            e2.description = "It's length is 7 feet";

            Equipment e3 = new Mobile();
            e3.name = "JCB";
            e3.description = "It is used for building construction purposes";
            e3.moveBy(4, 3);

            Equipment e4 = new Mobile();

            e4 = e1;

            List<Equipment> items = new List<Equipment>(2);
            items.Add(e1);
            items.Add(e2);
            items.Add(e3);
            items.Add(e4);

            for(int i=0; i<items.Count; i++)
            {
                Equipment e = items[i];
                Console.WriteLine(e.name);
                Console.WriteLine(e.description);
                Console.WriteLine();
            }

            foreach(Equipment e in items)
            {
                e.show();
            }

            List<Equipment> mob = items.FindAll(e => e.Type == EquipType.mobile);
            foreach(Equipment e in mob)
            {
                e.show();
            }

            List<Equipment> immob = items.FindAll(e => e.Type == EquipType.immobile);
            foreach (Equipment e in immob)
            {
                e.show();
            }

            List<Equipment> notMoved = items.FindAll(e => e.distanceMoved == 0);
            foreach(Equipment e in notMoved)
            {
                e.show();
            }

            items.Remove(e1);



            //e1.show();
            //e2.show();

        }
    }
}

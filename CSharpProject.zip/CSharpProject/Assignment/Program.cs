﻿using System;
using Exercise1;
using Exercise2;
using Exercise3;
using Exercise4;
using Exercise5;
using Exercise6;
using Exercise7;
using Exercise8;
using Exercise9;
using Exercise10;
using Exercise11;
using Exercise12;
using Exercise13;
using Exercise14;
using Exercise15;
using Exercise16;
using Exercise17;

namespace Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;
            x = int.Parse(Console.ReadLine());
            if(x == 1)
            {
                Program1 a = new Program1();
                a.Question1();
            }
            else if(x == 2)
            {
                Program2 a = new Program2();
                a.Question2();
            }
            else if(x == 3)
            {
                Program3 a = new Program3();
                a.Question3();
            }
            else if(x == 4)
            {
                Program4 a = new Program4();
                a.Question4();
            }
            else if(x == 5)
            {
                Program5 a = new Program5();
                a.Question5();
            }
            else if(x == 6)
            {
                Program6 a = new Program6();
                a.Question6();
            }
            else if(x == 7)
            {
                Program7 a = new Program7();
                a.Question7();
            }
            else if(x == 8)
            {
                Program8 a = new Program8();
                a.Question8();
            }
            else if(x == 9)
            {
                Program9 a = new Program9();
                a.Question9();
            }
            else if(x == 10)
            {
                Program10 a = new Program10();
                a.Question10();
            }
            else if(x == 11)
            {
                Program11 a = new Program11();
                a.Question11();
            }
            else if(x == 12)
            {
                Program12 a = new Program12();
                a.Question12();
            }
            else if(x == 13)
            {
                Program13 a = new Program13();
                a.Question13();
            }
            else if(x == 14)
            {
                Program14 a = new Program14();
                a.Question14();
            }
            else if(x == 15)
            {
                Program15 a = new Program15();
                a.Question15();
            }
            else if(x == 16)
            {
                Program16 a = new Program16();
                a.Question16();
            }
            else if(x == 17)
            {
                Program17 a = new Program17();
                a.Question17();
            }
        }

        
    }
}

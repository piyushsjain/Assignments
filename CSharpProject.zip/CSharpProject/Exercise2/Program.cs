﻿using System;

namespace Exercise2
{
    public class Program2
    {
        public void Question2()
        {
            object o;
            object o1;
            o = "Hello World";
            o1 = o;

            Console.WriteLine(o == o1);         //This will return true as both have same reference
            Console.WriteLine(o.Equals(o1));    //This wiil also return true as both have same content
            Console.WriteLine(Object.ReferenceEquals(o, o1));


            object a;
            object a1;
            a = "CSharp";
            a1 = "CSharp";

            Console.WriteLine(a == a1);     //This will return false as reference of both the objects is not same
            Console.WriteLine(a.Equals(a1));    //As Content is same , it will return true
            Console.WriteLine(Object.ReferenceEquals(a, a1));




        }
    }
}

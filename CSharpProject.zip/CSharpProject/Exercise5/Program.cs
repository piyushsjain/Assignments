﻿using System;

namespace Exercise5
{
    public class Program5
    {
        public void Question5()
        {
            Rubber d1 = new Rubber();
            d1.weight(2);
            d1.numberOfWings(4);
            d1.show();
            
            Mallard d2 = new Mallard();
            d2.weight(5);
            d2.numberOfWings(2);
            d2.show();
            
            Redhead d3 = new Redhead();
            d3.weight(7);
            d3.numberOfWings(4);
            d3.show();            
        }
    }
}

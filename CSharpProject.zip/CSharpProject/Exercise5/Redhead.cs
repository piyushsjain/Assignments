﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise5
{
    class Redhead : IDuck,IFly,IQuack
    {
        int weigh, wings;
        string Fly,Quack;
        public DuckType Type { get; set; }
        public Redhead()
        {
            Type = DuckType.redhead;
        }
        public void weight(int w)
        {
            weigh = w;
        }
        public void numberOfWings(int nOW)
        {
            wings = nOW;
        }
        public void fly()
        {
            Fly = "Fly Slow";
            Console.WriteLine(Fly);
        }
        public void quack()
        {
            Quack = "Quack Mild";
            Console.WriteLine(Quack);
        }
        public void show()
        {
            Console.WriteLine("Redhead:");
            Console.WriteLine("Weight: " + weigh);
            Console.WriteLine("Number of Wings: " + wings);
            fly();
            quack();
            Console.WriteLine();
        }
    }
}

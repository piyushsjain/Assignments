﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise5
{
    class Rubber : IDuck,IFly,IQuack
    {
        public DuckType Type { get; set; }
        int weigh, wings;
        string Fly, Quack;
        public Rubber()
        {
            Type = DuckType.rubber;
        }
        public void weight(int w)
        {
            weigh = w;
        }
        public void numberOfWings(int nOW)
        {
            wings = nOW;
        }
        public void fly()
        {
            Fly = "Don't Fly";
            Console.WriteLine(Fly);
        }
        public void quack()
        {
            Quack = "Don't Quack";
            Console.WriteLine(Quack);
        }
        public void show()
        {
            Console.WriteLine("Rubber:");
            Console.WriteLine("Weight: " + weigh);
            Console.WriteLine("Number of Wings: " + wings);
            fly();
            quack();
            Console.WriteLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise5
{
    class Mallard : IDuck, IFly, IQuack
    {
        public DuckType Type { get; set; }
        int weigh, wings;
        string Fly,Quack;

        public Mallard()
        {
            Type = DuckType.mallard;
        }
        public void weight(int w)
        {
            weigh = w;
        }
        public  void numberOfWings(int nOW)
        {
            wings = nOW;
        }
        public void fly()
        {
            Fly = "Fly Fast";
            Console.WriteLine("Fly Fast");
        }
        public void quack()
        {
            Quack = "Quack Loud";
            Console.WriteLine("Quack Loud");
        }
        public void show()
        {
            Console.WriteLine("Mallard:");
            Console.WriteLine("Weight: "+weigh);
            Console.WriteLine("Number of Wings: "+wings);
            fly();
            quack();
            Console.WriteLine();
        }
    }
}

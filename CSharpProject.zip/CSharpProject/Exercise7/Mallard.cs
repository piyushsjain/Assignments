﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise7
{
    class Mallard : IDuck, IFly, IQuack
    {
        public DuckType Type { get; set; }
        int weigh, wings;
        string Fly, Quack;

        public Mallard()
        {
            Type = DuckType.mallard;
        }
        public void weight(int w)
        {
            weigh = w;
        }
        public void numberOfWings(int nOW)
        {
            wings = nOW;
        }
        public void fly()
        {
            Fly = "Fly Fast";
        }
        public void quack()
        {
            Quack = "Quack Loud";
        }
        public void show()
        {
            Console.WriteLine("Weight: " + weigh);
            Console.WriteLine("Number of Wings: " + wings);
            Console.WriteLine(Fly);
            Console.WriteLine(Quack);
            Console.WriteLine();
        }
    }
}

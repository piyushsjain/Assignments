﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise7
{
    public enum DuckType
    {
        rubber, mallard, redhead
    }


    interface IDuck
    {
        public void weight(int w);
        public void numberOfWings(int nOW);
    }
}

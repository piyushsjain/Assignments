﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise7
{
    class Rubber : IDuck, IFly, IQuack
    {
        public DuckType Type { get; set; }
        int weigh, wings;
        string Fly, Quack;
        public Rubber()
        {
            Type = DuckType.rubber;
        }
        public void weight(int w)
        {
            weigh = w;
        }
        public void numberOfWings(int nOW)
        {
            wings = nOW;
        }
        public void fly()
        {
            Fly = "Don't Fly";
        }
        public void quack()
        {
            Quack = "Don't Quack";
        }
        public void show()
        {
            Console.WriteLine("Weight: " + weigh);
            Console.WriteLine("Number of Wings: " + wings);
            Console.WriteLine(Fly);
            Console.WriteLine(Quack);
            Console.WriteLine();
        }
    }
}

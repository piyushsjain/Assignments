﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Exercise7
{
    public class Program7
    {
        private static bool Removal(Rubber r)
        {
            return true;
        }

        public void Question7()
        {
            Rubber e1 = new Rubber();
            e1.weight(2);
            e1.numberOfWings(4);
            e1.fly();
            e1.quack();

            Rubber e2 = new Rubber();
            e2.weight(5);
            e2.numberOfWings(6);
            e2.fly();
            e2.quack();

            Rubber e3 = new Rubber();
            e3.weight(4);
            e3.numberOfWings(2);
            e3.fly();
            e3.quack();

            List<Rubber> items = new List<Rubber>(3);
            items.Add(e1);
            items.Add(e2);
            items.Add(e3);

            for(int i=0; i<items.Count;i++)
            {
                items[i].show();
            }

            items.Remove(e2);
            Console.WriteLine("After Removal: ");
            for (int i = 0; i < items.Count; i++)
            {
                items[i].show();
            }

            items.RemoveAll(Removal);
            Console.WriteLine("Number of items in the list: {0}",items.Count);

            items.Add(e1);
            items.Add(e2);
            items.Add(e3);

            

            







        }
    }
}

﻿using System;

namespace Exercise3
{
    public class Program3
    {
        public void Question3()
        {
            int a;
            int b;
            Console.WriteLine("Enter first number");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second number");
            b = Convert.ToInt32(Console.ReadLine());

            for(int i=a;i<=b;i++)
            {
                int flag = 0;
                for(int j=2;j<=Math.Sqrt(i);j++)
                {
                    if(i%j == 0)
                    {
                        flag = 1;
                        break;
                    }
                }
                if (flag == 0)
                {
                    Console.WriteLine(i + " ");
                }
            }

        }
    }
}

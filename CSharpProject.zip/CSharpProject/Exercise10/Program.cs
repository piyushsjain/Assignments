﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exercise10
{
    public interface IPriority
    {
        public int Priority { get; set; }
    }

    class PriorityQueue<T> : IPriority
    {
        private IDictionary<int, List<T>> elements;
        public int Priority { get; set; }
        public PriorityQueue()
        {
            elements = new Dictionary<int, List<T>>();
            priorityList = new List<PriorityNode>();
        }
        //Dictionary<int, string> dict = new Dictionary<int, string>();

        private class PriorityNode
        {
            public int Priority { get; set; }
            public T Data { get; set; }
        }
        IList<PriorityNode> priorityList;

        

        public void enqueue(int priority, T value)
        {
            var item = new PriorityNode();
            item.Data = value;
            item.Priority = priority;
            priorityList.Add(item);
        }

        public T dequeue()
        {
            var item = elements.Keys.OrderBy(x => x).FirstOrDefault();
            var result = elements[item].FirstOrDefault();
            elements[item].RemoveAt(0);
            if (elements[item].Count == 0)
            {
                elements.Remove(item);
            }
            return result;
        }
    }



    public class Program10
    {
        public void Question10()
        {
            PriorityQueue<int> priorityQueue = new PriorityQueue<int>();
            priorityQueue.enqueue(1,1);
            priorityQueue.enqueue(2,4);
            priorityQueue.enqueue(0,7);

            priorityQueue.dequeue();



        }
    }
}
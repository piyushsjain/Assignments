﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise1
{
    public class Program1
    {
        public void Question1()
        {
            string str;
            int num;

            Console.WriteLine("Enter a number to convert in Int");
            str = Console.ReadLine();
            num = int.Parse(str);       // Using int.Parse to covert into int
            Console.WriteLine("Num is " + num);

            Console.WriteLine("Enter a number to convert in Int");
            str = Console.ReadLine();
            Console.WriteLine(int.TryParse(str, out num));      // Using Convert.ToInt32 to covert into int (returns int)
            Console.WriteLine(num);

            Console.WriteLine("Enter a number to convert in Int");
            str = Console.ReadLine();
            num = Convert.ToInt16(str);        // Using Convert.ToInt16 to covert into int (returns short)
            Console.WriteLine(str);





            float f;
            Console.WriteLine("Enter a number to convert in Float");
            f = float.Parse(str);        // Using Convert.ToInt32 to covert into int (returns int)
            Console.WriteLine(f);

            


            Console.WriteLine("Enter a number to convert in Float");
            str = Console.ReadLine();
            Console.WriteLine(float.TryParse(str, out f));      // Using Convert.ToInt32 to covert into int (returns int)
            Console.WriteLine(f);



            bool b;
            Console.WriteLine("Enter a number to convert in Bool");
            str = Console.ReadLine();
            b = bool.Parse(str);        // Using Convert.ToInt32 to covert into int (returns int)
            Console.WriteLine(f);

            Console.WriteLine("Enter a number to convert in Bool");
            str = Console.ReadLine();
            b = Convert.ToBoolean(str);        // Using Convert.ToInt16 to covert into int (returns short)
            Console.WriteLine(b);

            Console.WriteLine("Enter a number to convert in Bool");
            str = Console.ReadLine();
            Console.WriteLine(bool.TryParse(str, out b));      // Using Convert.ToInt32 to covert into int (returns int)
            Console.WriteLine(b);







        }
    }
}

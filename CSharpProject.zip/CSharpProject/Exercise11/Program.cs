﻿using System;

namespace Exercise11
{
    public class Program11
    {
        public void Question11()
        {
            int i;
            i = int.Parse(Console.ReadLine());
            if(i.IsOdd())
            {          
                Console.WriteLine("It is a Odd Number");
            }

            if (i.IsEven())
            {
                Console.WriteLine("it is a even number");
            }

            if (i.IsPrime())
            {
                Console.WriteLine("it is a prime number");
            }
            if (i.IsDivisible(5))
            {
                Console.Write("it is divisible");
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise11
{
    public static class ExtensionMethod
    {
        public static bool IsOdd(this int i)
        {
            if (i % 2 != 0)
                return true;
            return false;
        }
        public static bool IsEven(this int i)
        {
            if (i % 2 == 0)
                return true;
            return false;
        }
        public static bool IsPrime(this int i)
        {
            for(int j=2; j<Math.Sqrt(i); j++)
            {
                if (i % j == 0)
                    return false;
            }
            return true;
        }
        public static bool IsDivisible(this int i,int j)
        {
            if (i % j == 0)
                return true;
            return false;
        }
    }
}

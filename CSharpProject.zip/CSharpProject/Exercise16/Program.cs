﻿using System;
using System.IO;
using System.Linq;

namespace Exercise16
{
    public class Program16
    {
        public void Question16()
        {
            DirectoryInfo a = new DirectoryInfo(@"C:\Users\piyushjain01\Documents\IISExpress");
            int numberTextFiles = a.GetFiles().ToList().Where(file => file.FullName.Contains(".txt")).Count();
            Console.WriteLine(numberTextFiles);



            int numberJpgFiles = a.GetFiles().ToList().Where(file => file.FullName.Contains(".jpg")).Count();
            Console.WriteLine(numberJpgFiles);




            var Files = a.GetFiles().OrderByDescending(file => file.Length).Take(5).ToList();
            foreach (FileInfo fileInfo in Files)
            {
                Console.WriteLine("The file \"{0}\" has size {1} MB", fileInfo.Name, fileInfo.Length / 1024f / 1024f);
            }




            if (Files.Count != 0)
                Console.WriteLine("\nThe file \"{0}\" has maximum length in the directory {1} MB", ((FileInfo)Files[0]).Name, ((FileInfo)Files[0]).Length / 1024f / 1024f);
            else
                Console.WriteLine("The directory does not exist.");
        }
    }
}



   


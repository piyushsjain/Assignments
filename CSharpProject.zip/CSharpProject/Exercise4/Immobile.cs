﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise4
{
    class Immobile : Equipment
    {
        public Immobile()
        {
            Type = EquipType.immobile;
        }
        public override void moveBy(int n, int d)
        {
            distanceMoved += d;
            maintanenceCost += n * d;
        }
    }
}

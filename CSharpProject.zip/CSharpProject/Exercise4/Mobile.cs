﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise4
{
    public class Mobile : Equipment
    {
        public Mobile()
        {
            Type = EquipType.mobile;
        }
        public override void moveBy(int n, int d)
        {
            distanceMoved += d;
            maintanenceCost += n * d;
        }
    }
}

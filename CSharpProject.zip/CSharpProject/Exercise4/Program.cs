﻿using System;

namespace Exercise4
{
    public class Program4
    {
        public void Question4()
        {
            Mobile e1 = new Mobile();
            e1.name = "Car";
            e1.description = "It has 4 tyres";
            e1.moveBy(2, 4);
            e1.show();

            Immobile e2 = new Immobile();
            e2.name = "Ladder";
            e2.description = "We can from one floor to another by using ladder";
            e2.moveBy(4,5);
            e2.show();


        }
    }
}

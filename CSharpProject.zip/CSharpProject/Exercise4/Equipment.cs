﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise4
{
     public enum EquipType
    {
        mobile,immobile
    }
    public abstract class Equipment
    {
        public string name { get; set; }
        public string description { get; set; }
        public int distanceMoved { get; set; }
        public int  maintanenceCost { get; set; }

        public abstract void moveBy(int n, int d);

        public void show()
        {
            Console.WriteLine(name); 
            Console.WriteLine(description); 
            Console.WriteLine(distanceMoved); 
            Console.WriteLine(maintanenceCost); 
            Console.WriteLine(Type); 


        }

        public EquipType Type { get; set; }

    }

}

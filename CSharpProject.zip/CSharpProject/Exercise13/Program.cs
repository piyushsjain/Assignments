﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exercise13
{
    public static class Extension
    {
        public static bool CustomAll<T>(this IEnumerable<T> item, Func<T,bool> func)
        {
            return item.All(func);
        }
        public static bool CustomAny<T>(this IEnumerable<T> item, Func<T, bool> func)
        {
            return item.Any(func);

        }
        public static bool CustomMax<T>(this IEnumerable<T> item, Func<T, bool> func)
        {
            return item.Max(func);

        }
        public static bool CustomMin<T>(this IEnumerable<T> item, Func<T, bool> func)
        {
            return item.Min(func);

        }
        public static IEnumerable<bool> CustomSelect<T>(this IEnumerable<T> item, Func<T, bool> func)
        {
            return item.Select(func);
        }
        public static IEnumerable<T> CustomWhere<T>(this IEnumerable<T> item, Func<T, bool> func)
        {
            return item.Where(func);
        }
    }


    public class Program13
    {
        public void Question13()
        {
            List<Customr> Customers = new List<Customr>();

            Customr customer1 = new Customr()
            {
                ID = 1,
                Name = "Jack",
                Salary = 3500
            };

            Customr customer2 = new Customr()
            {
                ID = 2,
                Name = "John",
                Salary = 5000
            };

            Customr customer3 = new Customr()
            {
                ID = 3,
                Name = "Mike",
                Salary = 3000
            };

            Customr customer4 = new Customr()
            {
                ID = 4,
                Name = "Schweb",
                Salary = 5500
            };

            Customers.Add(customer1);
            Customers.Add(customer2);
            Customers.Add(customer3);
            Customers.Add(customer4);


            Console.WriteLine(Customers.CustomAll(x => x.ID > 0));
            Console.WriteLine(Customers.CustomAny(x => x.ID > 4));
            Console.WriteLine(Customers.CustomMax(x => x.ID > 1));
            Console.WriteLine(Customers.CustomMin(x => x.ID < 1));
            //Console.WriteLine(Customers.CustomSelect(x => x.ID > 0));
            Console.WriteLine(string.Join(", ", Customers.CustomSelect(x => x.ID > 2)));
            Console.WriteLine(string.Join(", ", Customers.CustomWhere(x => x.ID > 1)));
            //Console.WriteLine(Customers.CustomWhere(x => x.ID > 0));














        }
    }
}

            //int count = System.IO.Directory.EnumerateFiles("").Count();
            /*Directory.GetFiles(path, "*.txt", SearchOption.AllDirectories)";"


                var di = new DirectoryInfo("someDirectory");

            var result = di.GetFiles().OrderByDescending(x => x.Length).Take(5).ToList();*/
﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exercise9
{
    public interface IPriority
    {
        public int Priority { get; set; }
    }

    class PriorityQueue<T> : IPriority
    {
        private IDictionary<int, List<T>> elements;
        public int Priority { get; set; }
        public PriorityQueue()
        {
            elements = new Dictionary<int, List<T>>();
            priorityList = new List<PriorityNode>();
        }
        //Dictionary<int, string> dict = new Dictionary<int, string>();

        private class PriorityNode
        {
            public int Priority { get; set; }
            public T Data { get; set; }
        }
        IList<PriorityNode> priorityList;

        

        public void enqueue(T value)
        {
            if (elements.ContainsKey(Priority))
            {
                elements[Priority].Add(value);
            }
            else
            {
                var items = new List<T>();
                items.Add(value);
                elements[Priority] = items;
            }
        }

        

        public T dequeue()
        {
            var item = elements.Keys.OrderBy(x => x).FirstOrDefault();
            var result = elements[item].FirstOrDefault();
            elements[item].RemoveAt(0);
            if (elements[item].Count == 0)
            {
                elements.Remove(item);
            }
            return result;
        }
    }



    public class Program9
    {
        public void Question9()
        {
            PriorityQueue<int> priorityQueue = new PriorityQueue<int>();
            priorityQueue.enqueue(1);
            priorityQueue.enqueue(4);
            priorityQueue.enqueue(7);

            priorityQueue.dequeue();


            
        }
    }
}
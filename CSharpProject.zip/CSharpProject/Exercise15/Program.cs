﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace Exercise15
{
    public class Program15
    {
        static void num_changed(object sender, NotifyCollectionChangedEventArgs e)
        {
            Console.WriteLine("\nAction: " + e.Action);
            if (e.NewItems != null)
            {
                Console.WriteLine("\nNumber added: ");
                foreach (var item in e.NewItems)
                {
                    Console.WriteLine(item);
                }
            }

            if (e.OldItems != null)
            {
                Console.WriteLine("\nNumber removed: ");
                foreach (var item in e.OldItems)
                {
                    Console.WriteLine(item);
                }
            }
        }


        public  void Question15()
        {
            ObservableCollection<int> num = new ObservableCollection<int>();
            num.CollectionChanged += num_changed;

            num.Add(3);
            num.Add(6);
            num.Remove(3);
            num.Add(11);
            num.Add(90);
            num.Remove(11);
        }
    }
}
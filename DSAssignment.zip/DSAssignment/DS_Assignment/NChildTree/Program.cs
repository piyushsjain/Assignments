﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace NChildTree
{
    public class Node
    {
        public int data;
        public List<Node> children;
        public Node(int d)
        {
            data = d;
            children = new List<Node>();
        }        
    }
    public class NChildTree
    {
        private Node root;

        public NChildTree()
        {
            this.root = constructGT(null, 0);
        }
        private Node constructGT(Node parent, int i)
        {
            if (parent == null)
            {
                Console.WriteLine("Enter data for root node: ");
            }
            else
            {
                Console.WriteLine("Enter data for the {0}th child of {1}", i + 1, parent.data);
            }

            int data = int.Parse(Console.ReadLine());
            Node node = new Node(data);

            Console.WriteLine("Enter the number of children for " + node.data);
            int n = int.Parse(Console.ReadLine());

            for (int j = 0; j < n; j++)
            {
                Node child = constructGT(node, j);
                node.children.Add(child);
            }
            return node;
        }

        public void Display()
        {
            Display(this.root);
        }
        private void Display(Node node)
        {

            String str = node.data + " => ";
            String res = node.data + " => ";
            foreach (Node child in node.children)
            {
                str += child.data + ", ";
            }

            if (str.Equals(res)) Console.WriteLine(str + "Null");
            else Console.WriteLine(str.Substring(0, str.Length - 2));

            foreach (Node child in node.children)  
            {
                Display(child);
            }
        }

        public void Insert(int val, int parent)
        {
            Node valNode = new Node(val);
            if (!InsertHelper(this.root, valNode, parent))
                Console.WriteLine("Parent not found");
        }
        private Boolean InsertHelper(Node node, Node val, int parent)
        {
            if (node.data == parent)
            {
                node.children.Add(val);
                return true;
            }

            foreach (Node child in node.children)
            {
                if (InsertHelper(child, val, parent))
                {
                    return true;
                }
            }
            return false;
        }

        public Boolean Contain(int element)
        {
            return ContainsHelper(this.root, element);
        }
        private Boolean ContainsHelper(Node node, int element)
        {
            if (node.data == element)
            {
                return true;
            }

            foreach (Node child in node.children)
            {
                if (ContainsHelper(child, element))
                {
                    return true;
                }
            }
            return false;
        }

        public void Delete(int r)
        {
            if (!Contain(r))
            {
                Console.WriteLine("Node not Found");
            }
            else if (this.root.data == r) 
            {
                for (int i = 1; i < this.root.children.Count(); i++)
                {
                    this.root.children[0].children.Add(this.root.children[i]);
                }
                this.root = this.root.children[0];
            }
            else
            {
                DeleteHelper(this.root, r);
            }
        }

        private void DeleteHelper(Node tempRoot, int r)
        {
            if (tempRoot.children != null)
            {
                for (int i = 0; i < tempRoot.children.Count(); i++)
                {
                    if (tempRoot.children[i].data == r)
                    {
                        foreach (Node n in tempRoot.children[i].children)
                        {
                            tempRoot.children.Add(n);
                        }
                        tempRoot.children.RemoveAt(i);
                    }
                    else
                    {
                        Node tempRoot2 = tempRoot.children[i];
                        DeleteHelper(tempRoot2, r);
                    }
                }
            }
        }

        public void GetElementsByLevel(int level)
        {
            Node root = this.root;
            int currLevel = 0;
            Queue<Node> q = new Queue<Node>();
            q.Enqueue(root);                                                
            int size = 1;                   
            while (q.Count() != 0)                
            {                           
                Node node = q.Dequeue();
                size--;

                if (currLevel == level)
                    Console.WriteLine(node.data + " ");

                foreach (Node child in node.children)
                {
                    q.Enqueue(child);
                }

                if (size == 0)
                {
                    currLevel += 1;
                    size = q.Count();
                }
            }
        }

        public void BFSTraversal()
        {

            Node root = this.root;

            Queue<Node> q = new Queue<Node>();
            q.Enqueue(root);
            int size = 1;

            while (q.Count() != 0)
            {
                Node node = q.Dequeue();
                size--;

                Console.WriteLine(node.data + " ");

                foreach (Node child in node.children)
                {
                    q.Enqueue(child);
                }

                if (size == 0)
                {
                    size = q.Count();
                }
            }
        }
        public void DFSTraversal()
        {
            DFSTraversalHelper(this.root);
        }
        private void DFSTraversalHelper(Node node)
        {
            Console.WriteLine(node.data + " ");
            foreach (Node n in node.children)
            {
                DFSTraversalHelper(n);
            }
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\nConstruct the Nth Child Tree\n");
            NChildTree tree = new NChildTree();
            Console.WriteLine("\nTree display : ");
            tree.Display();

            Console.WriteLine();
            int choice = -1;

            Console.WriteLine("1. Insert");
            Console.WriteLine("2. Delete");
            Console.WriteLine("3. Contain");
            Console.WriteLine("4. GetElementsByLevel");
            Console.WriteLine("5. Display");
            Console.WriteLine("6. BFS Traversal");
            Console.WriteLine("7. DFS Traversal");
            Console.WriteLine("8. Exit");

            while (choice != 8)
            {
                try
                {
                    Console.Write("\nYour choice: ");
                    choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            Console.Write("\nEnter value: ");
                            int val = int.Parse(Console.ReadLine());
                            Console.Write("Enter parent: ");
                            int parent = int.Parse(Console.ReadLine());
                            tree.Insert(val, parent);
                            break;

                        case 2:
                            Console.Write("\nEnter value: ");
                            val = int.Parse(Console.ReadLine());
                            tree.Delete(val);
                            break;

                        case 3:
                            Console.Write("\nEnter value: ");
                            val = int.Parse(Console.ReadLine());
                            if (tree.Contain(val))
                            {
                                Console.WriteLine("Nth Child Tree contain this value");
                            }
                            else Console.WriteLine("Nth Child Tree doesn't contain this value");
                            break;

                        case 4:
                            Console.Write("\nEnter level: ");
                            int level = int.Parse(Console.ReadLine());
                            tree.GetElementsByLevel(level);
                            break;

                        case 5:
                            tree.Display();
                            break;

                        case 6:
                            tree.BFSTraversal();
                            break;

                        case 7:
                            tree.DFSTraversal();
                            break;

                        case 8: break;

                        default:
                            Console.WriteLine("Error: Invalid choice!!!");
                            break;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Error: Choice shoud be an integer");
                }
            }
            Console.ReadKey();
        }
    }
}

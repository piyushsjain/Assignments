﻿using System;

namespace LinkedList
{
    public class linkedList
    {
        public Node head = null;
        public class Node
        {
            public int data;
            public Node next;
            public Node(int d)
            {
                data = d;
                next = null;
            }
        }
        public void insertAtFirst(int d)
        {
            Node newNode = new Node(d);
            newNode.next = head;
            head = newNode;
        }
        public void insertAfter(int p, int d)
        {
            Node temp = head;
            while(temp.data != p)
            {
                temp = temp.next;
                if(temp == null)
                {
                    Console.WriteLine("Node with value {0} does not exist", p);
                    return;
                }
            }
            Node newNode = new Node(d);
            newNode.next = temp.next;
            temp.next = newNode;
        }
        public void insertAtLast(int d)
        {
            Node newNode = new Node(d);
            if (head == null)
            {
                head = newNode;
                return;
            }
            newNode.next = null;
            Node temp = head;
            while (temp.next != null)
            {
                temp = temp.next;
            }
            temp.next = newNode;
            return;
        }
        public void deleteNode(int d)
        {
            Node temp = head;
            Node prev = head;
            while (temp.data != d)
            {
                prev = temp;
                temp = temp.next;

                if (temp == null)
                {
                    Console.WriteLine("Node with value {0} does not exist", d);
                    return;
                }
            }
            if (prev == head)
            {
                head = prev.next;
                return;
            }
            prev.next = temp.next;
        }
        public void deleteAt(int p)
        {
            if (p <= 0 || head == null)
                return;

            Node temp = head;
            Node prev = head;
            while (p>1 && temp.next != null)
            {
                prev = temp;
                temp = temp.next;
                p--;
            }
            prev.next = temp.next;
        }
        public void Center()
        {
            Node slowPtr = head;
            Node fastPtr = head;
            if (head == null)
            {
                Console.WriteLine("Linked List does not have values");
                return;
            }
            while(fastPtr!=null && fastPtr.next!= null)
            {
                slowPtr = slowPtr.next;
                fastPtr = fastPtr.next.next;
            }
            Console.WriteLine("Center is: " + slowPtr.data);
        }
        public void Reverse()
        {
            Node prevPtr = null;
            Node currentPtr = head;
            Node nextPtr;

            while(currentPtr != null)
            {
                nextPtr = currentPtr.next;
                currentPtr.next = prevPtr;

                prevPtr = currentPtr;
                currentPtr = nextPtr;
            }
            head = prevPtr;
        }
        public void Size()
        {
            Node temp = head;
            int count = 0;
            while(temp != null)
            {
                temp = temp.next;
                count++;
            }
            Console.WriteLine("Size of Linked List is: " + count);
        }
        public void print()
        {
            Node temp = head;
            while (temp != null)
            {
                Console.Write(temp.data + " ");
                temp = temp.next;
            }
            Console.WriteLine();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            linkedList list = new linkedList();
            list.insertAtFirst(5);
            list.insertAtFirst(7);
            list.print();
            list.insertAtFirst(9);
            list.print();
            list.deleteNode(9);
            list.print();
            list.insertAfter(7, 11);
            list.print();
            list.insertAtLast(9);
            list.print();
            list.Size();
            list.Center();
            list.deleteAt(3);
            list.print();
            list.Center();
            list.Size();
            list.Reverse();
            Console.Write("Reverse of Linked List : ");
            list.print();
            list.deleteNode(12);
            list.print();
        }
    }
}
    
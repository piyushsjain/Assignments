﻿using System;

namespace PriorityQueue
{
    public class PriorityQueue
    {
        public Node head = null;
        public class Node
        {
            public int data;
            public int priority;
            public Node next;
            public Node(int d, int p)
            {
                data = d;
                priority = p;
                next = null;
            }
        } 
        public void enqueue(int d, int p)
        {
            Node newNode = new Node(d,p);
            if(head == null)
            {
                head = newNode;
                newNode.next = null;
                return;
            }
            if(head.priority > p)
            {
                newNode.next = head;
                head = newNode;
            }
            else
            {
                Node temp = head;
                while (temp.priority < p && temp.next != null)
                {
                    temp = temp.next;
                }
                temp.next = newNode;
            }
        }
        public void dequeue()
        {
            if (head == null)
            {
                Console.WriteLine("----Queue Underflow----");
                return;
            }
            head = head.next;
        }
        public void peek()
        {
            if (head == null)
            {
                Console.WriteLine("Priority Queue is empty");
                return;
            }
            Console.WriteLine("At Peak");
            Console.WriteLine("Data : {0}   Priority : {1}", head.data, head.priority);
            Console.WriteLine();

        }
        public bool contains(int d)
        {
            if (head == null) 
                return false;

            Node temp = head;
            while(temp != null)
            {
                if (temp.data == d)
                    return true;
                temp = temp.next;
            }
            return false;
        }
        public void size()
        {
            if (head == null)
            {
                Console.WriteLine("No element is Present");
                return;
            }

            int count = 0;
            Node temp = head;
            while (temp != null)
            {
                count++;
                temp = temp.next;
            }
            Console.WriteLine("Size is : {0}", count);
        }
        public void reverse()
        {
            Node prevPtr = null;
            Node currentPtr = head;
            Node nextPtr;

            while (currentPtr != null)
            {
                nextPtr = currentPtr.next;
                currentPtr.next = prevPtr;

                prevPtr = currentPtr;
                currentPtr = nextPtr;
            }
            head = prevPtr;
        }
        public void print()
        {
            if(head == null)
            {
                Console.WriteLine("Priority Queue is empty");
                return;
            }
            Node temp = head;
            Console.WriteLine("data  priority");
            while (temp != null)
            {
                Console.WriteLine(temp.data + "     " + temp.priority);
                temp = temp.next;
            }
            Console.WriteLine();

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            PriorityQueue pq = new PriorityQueue();
            pq.enqueue(2, 3);
            pq.enqueue(11, 2);
            pq.enqueue(5, 4);
            pq.enqueue(6, 5);
            pq.print();
            pq.size();

            pq.dequeue();
            pq.print();

            pq.peek();
            pq.size();

            pq.reverse();
            pq.print();

            Console.WriteLine(pq.contains(11));
            
            pq.dequeue();
            pq.print();

        }
    }
}

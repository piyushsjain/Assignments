﻿using System;

namespace Queue
{
    class Queue
    {
        int front = 0;
        int back = -1;
        int limit = 1;
        int[] arr = new int[1];
        void upgrade()
        {
            limit *= 2;
            Array.Resize(ref arr, limit);
        }
        public void enqueue(int d)
        {
            if (back == limit - 1)
                upgrade();
            
            back++;
            arr[back] = d;
        }
        public void dequeue()
        {
            if (front > back)
            {
                Console.WriteLine("No element present in Queue");
                return;
            }
            front++;
        }
        public void peek()
        {
            if (front > back)
            {
                Console.WriteLine("No element present in Queue");
                return;
            }
            Console.WriteLine("Top element is : " + arr[front]);
        }
        public bool contains(int d)
        {
            if (front > back)
                return false;
            for(int i = front; i <= back; i++)
            {
                if (arr[i] == d)
                    return true;
            }
            return false;
        }
        public int size()
        {
            return back - front + 1;
        }
        public void reverse()
        {
            for (int i = front, j = back; i != j && i < j; i++, j--)
            {
                int temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }
        }
        public void print()
        {
            for (int i = front; i <=back; i++)
            {
                Console.Write(arr[i] + " ");
            }
            Console.WriteLine();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Queue q = new Queue();
            q.enqueue(2);
            q.enqueue(3);
            q.enqueue(5);
            q.enqueue(7);
            q.enqueue(9);
            
            q.print();

            q.dequeue();
            q.print();

            Console.WriteLine(q.contains(5) ? "5 is present" : "5 is not present");

            q.peek();

            Console.WriteLine(q.size());

            q.reverse();
            q.print();

        }
    }
}

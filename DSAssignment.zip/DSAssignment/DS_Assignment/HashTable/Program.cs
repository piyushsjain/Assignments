﻿using System;

namespace HashTable
{
	public class Entry<K, V>
	{
		public K key;
		public V value;
		public Entry<K, V> next;
		public Entry(K key, V value, Entry<K, V> next)
		{
			this.key = key;
			this.value = value;
			this.next = next;
		}
	}
    public class CustomException : Exception
    {
        public CustomException()
        {
        }
        public CustomException(string message)
            : base(message)
        {
        }

        public CustomException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
	public class HashTable<K, V>
	{
		private Entry<K, V>[] table; 
		private readonly int capacity; 

		public HashTable(int capacity)
		{
			this.capacity = capacity;
			table = new Entry<K, V>[capacity];
		}
		private int hash(K key)
		{
			return (key.GetHashCode()) % capacity;
		}

		public void Insert(K new_key, V data)
		{
			if (new_key == null)  
				return;

			int x = hash(new_key); 

			Entry<K, V> new_entry = new Entry<K, V>(new_key, data, null); 

			if (table[x] == null) 
			{
				table[x] = new_entry;
			}
			else 
			{   
				Entry<K, V> prev = null;
				Entry<K, V> ptr = table[x];
				while (ptr != null)
				{
					if (ptr.key.Equals(new_key))
					{
						if (prev == null) 
						{
							new_entry.next = ptr.next;
							table[x] = new_entry;
							return;
						}
						else
						{
							prev.next = new_entry;
							new_entry.next = ptr.next;
							return;
						}
					}
					prev = ptr;
					ptr = ptr.next;
				}
				prev.next = new_entry; 

			}
		}
		public void Delete(K deleteKey)
		{

			int x = hash(deleteKey);

			if (table[x] == null) throw new CustomException("Hash table has no entry for key = " + deleteKey);

			else
			{
				Entry<K, V> prev = null;
				Entry<K, V> ptr = table[x];

				while (ptr != null)
				{
					if (ptr.key.Equals(deleteKey))
					{
						if (prev == null)
						{
							table[x] = table[x].next;
							return;
						}
						else
						{
							prev.next = ptr.next;
							return;
						}
					}
					prev = ptr;
					ptr = ptr.next;
				}
				throw new CustomException("Hash table has no entry for key = " + deleteKey);
			}
		}

		public Boolean Contain(V val)
		{
			for (int i = 0; i < capacity; i++)
			{
				if (table[i] != null)
				{
					Entry<K, V> entry = table[i];
					while (entry != null)
					{
						if (entry.value.Equals(val)) 
						{                           
							return true;
						}
						entry = entry.next;
					}
				}
			}
			return false;
		}

		public object GetValueByKey(K key)
		{
			int x = hash(key);
			if (table[x] == null)
			{
				return null;
			}
			else
			{
				Entry<K, V> temp = table[x];
				while (temp != null)
				{
					if (temp.key.Equals(key))
						return temp.value;
					temp = temp.next;
				}
				return null; 
			}
		}

		public int Size()  
		{
			int count = 0;
			for (int i = 0; i < capacity; i++)
			{
				if (table[i] != null)
				{
					Entry<K, V> entry = table[i];
					while (entry != null)
					{
						count++;
						entry = entry.next;
					}
				}
			}
			return count;
		}
		public void Iterator()
		{
			Console.WriteLine("Hash Table: ");
			for (int i = 0; i < capacity; i++)
			{
				if (table[i] != null)
				{
					Entry<K, V> entry = table[i];
					while (entry != null)
					{
						Console.WriteLine("{ " + entry.key + "=" + entry.value + " }");
						entry = entry.next;
					}
				}
			}
		}

		public void Print()
		{
			Console.WriteLine("Hash Table: ");
			for (int i = 0; i < capacity; i++)
			{
				if (table[i] != null)
				{
					Entry<K, V> entry = table[i];
					while (entry != null)
					{
						Console.WriteLine("{ " + entry.key + "=" + entry.value + " }");
						entry = entry.next;
					}
				}
			}
		}
	}
	class Program
    {
        static void Main(string[] args)
        {
			Console.WriteLine("1. Insert");
			Console.WriteLine("2. Delete");
			Console.WriteLine("3. Contain");
			Console.WriteLine("4. Get value by Key");
			Console.WriteLine("5. Size");
			Console.WriteLine("6. Iterator");
			Console.WriteLine("7. Traverse/Print");
			Console.WriteLine("8. Exit");

			Console.Write("\nEnter the capacity of Hash Table: ");
			int capacity = int.Parse(Console.ReadLine());

	
			HashTable<int, string> hash = new HashTable<int, string>(capacity);

			int choice = -1, key;

			while (choice != 8)
			{
				try
				{
					Console.Write("\nYour choice : ");
					choice = int.Parse(Console.ReadLine());

					switch (choice)
					{
						case 1:
							try
							{
								Console.Write("\nEnter key: ");
								key = int.Parse(Console.ReadLine());
								Console.Write("Enter data: ");
								String data = Console.ReadLine();
								hash.Insert(key, data);
							}
							catch (FormatException)
							{
								Console.WriteLine("Error: Key should be an integer.");
							}
							break;

						case 2:
							try
							{
								Console.Write("\nEnter key: ");
								key = int.Parse(Console.ReadLine());
								hash.Delete(key);
							}
							catch (FormatException)
							{
								Console.WriteLine("Error: Key should be an integer.");
							}
							catch (CustomException e)
							{
								Console.WriteLine(e.Message);
							}
							break;

						case 3:
							Console.Write("\nEnter data: ");
							if (hash.Contain(Console.ReadLine()))
							{
								Console.WriteLine("Hash Table contain this element");
							}
							else Console.WriteLine("Hash Table doesn't contain this element");
							break;

						case 4:
							try
							{
								Console.Write("\nEnter key: ");
								key = int.Parse(Console.ReadLine());
								var output = hash.GetValueByKey(key);
								if (output != null)
								{
									Console.WriteLine("Value: " + output);
								}
								else Console.WriteLine("Null");
							}
							catch (FormatException)
							{
								Console.WriteLine("Error: Key should be an integer.");
							}
							break;

						case 5:
							Console.WriteLine("\nSize of Hash Table: " + hash.Size());
							break;

						case 6:
							hash.Iterator();
							break;

						case 7:
							hash.Print();
							break;

						case 8: break;

						default:
							Console.WriteLine("Error: Invalid choice!!!");
							break;
					}
				}
				catch (FormatException)
				{
					Console.WriteLine("Error: Choice should be an integer.");
				}

			}
			Console.ReadKey();
		}
    }
}

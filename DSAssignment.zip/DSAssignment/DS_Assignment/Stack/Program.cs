﻿using System;

namespace Stack
{
    public class Stack
    {
        int top = -1;
        int limit = 1;
        int[] arr = new int[1];
        void upgrade()
        {
            limit = 2 * limit;
            Array.Resize(ref arr, limit);
        }
        public void push(int d)
        {
            if (top == limit-1)
                upgrade();

            top++;
            arr[top] = d;
        }
        public void pop()
        {
            if(top == -1)
            {
                Console.WriteLine("----Stack underflow----");
                return;
            }
            top--;
        }
        public void peek()
        {
            Console.WriteLine(arr[top]);
        }
        public bool contains(int d)
        {
            foreach(var ele in arr)
            {
                if (arr[ele] == d)
                    return true;
            }
            return false;
        }
        public int size()
        {
            return top+1;
        }
        public void reverse()
        {
            for(int i=0,j=top;i!=j && i<j; i++, j--)
            {
                int temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }
        }
        public void print()
        {
            for(int i=top; i>=0;i--)
            {
                Console.Write(arr[i] + " ");
            }
            Console.WriteLine();
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Stack st = new Stack();
            st.push(1);
            st.push(5);
            st.push(3);
            st.push(7);
            st.push(4);

            st.pop();

            st.peek();

            st.print();

            st.reverse();
            st.print();

            Console.WriteLine(st.size());

            Console.WriteLine( st.contains(5) ? "5 is present" : "5 is not present" );
        }
    }
}
